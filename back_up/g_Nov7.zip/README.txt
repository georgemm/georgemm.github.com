READ ME

my Goals are to learn:

-html
-css
-javascript
-jquery
-php
-SQL
-ruby
-SSI
- etc.

So far I've made this:

-ruby 1.9.3 Folder contains a 'ruby script' that when run will create a folder structure suitable for creating a small website.



