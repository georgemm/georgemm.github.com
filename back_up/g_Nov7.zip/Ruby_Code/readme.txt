<!--- Page Created by: GMM-Web Design.--->
I like to prototype in ruby code. So heers a scratch pad for you.
